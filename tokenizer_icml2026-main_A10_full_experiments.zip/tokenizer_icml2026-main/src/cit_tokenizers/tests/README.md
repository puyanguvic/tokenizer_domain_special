Golden tests are expected in your repo; kept out of this minimal package.
